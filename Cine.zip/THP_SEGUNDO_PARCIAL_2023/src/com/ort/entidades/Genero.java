package com.ort.entidades;

public enum Genero {
	FEMENINO, MASCULINO, OTRO
}
