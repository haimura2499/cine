package com.ort.aplicacion;

public enum ResultadoCambiarSalaFuncion {
	FUNCION_INEXISTENTE, SALA_INEXISTENTE, CAPACIDAD_SALA_INSUFICIENTE, OK
}
