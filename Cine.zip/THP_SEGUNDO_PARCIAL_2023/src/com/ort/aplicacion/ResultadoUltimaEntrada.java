package com.ort.aplicacion;

public enum ResultadoUltimaEntrada {
	CLIENTE_INEXISTENTE, CLIENTE_SIN_ENTRADAS, OK
}
